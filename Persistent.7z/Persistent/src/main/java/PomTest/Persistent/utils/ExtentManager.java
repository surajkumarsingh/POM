package PomTest.Persistent.utils;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {

	private static ExtentReports extent;

	public static ExtentReports getInstance() {
		if (extent == null) {
			return createInstance("test-output/extent.html");
		} else {

			return extent;
		}
	}

	public static ExtentReports createInstance(String fileName) {
		ExtentHtmlReporter htmlReport = new ExtentHtmlReporter(fileName);
		htmlReport.config().setTestViewChartLocation(ChartLocation.BOTTOM);
		htmlReport.config().setChartVisibilityOnOpen(true);
		htmlReport.config().setTheme(Theme.STANDARD);
		htmlReport.config().setDocumentTitle(fileName);
		htmlReport.config().setEncoding("utf-8");
		htmlReport.config().setReportName(fileName);
		extent = new ExtentReports();
		extent.attachReporter(htmlReport);
		return extent;

	}

}
