package PomTest.Persistent.helper.wait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import PomTest.Persistent.helper.logger.LoggerHelper;
/**
 * 
 * @author suraj_kumar
 *
 */
public class WaitHelper {
	private WebDriver driver;

	private Logger log = LoggerHelper.getLogger(WaitHelper.class);

	public WaitHelper(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * This is ImplicitWait method
	 * 
	 * @param timeout
	 * @param unit
	 */
	public void setImplicitWait(long timeout, TimeUnit unit) {
		log.info("Implicit wait has been set to:" + timeout);
		driver.manage().timeouts().implicitlyWait(timeout, unit);
	}

	/**
	 * This will help us to get WebdriverWaitobject
	 * 
	 * @param timeOutSeconds
	 * @param pollingEveryInMilliSec
	 * @return
	 */
	private WebDriverWait getWait(int timeOutSeconds, int pollingEveryInMilliSec) {
		WebDriverWait wait = new WebDriverWait(driver, timeOutSeconds);
		wait.pollingEvery(Duration.ofMillis(pollingEveryInMilliSec));
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(ElementNotVisibleException.class);
		wait.ignoring(StaleElementReferenceException.class);
		wait.ignoring(NoSuchFrameException.class);
		return wait;
	}

	/**
	 * This method will make sure element is visible
	 * 
	 * @param element
	 * @param timeOutSeconds
	 * @param pollingEveryInMilliSec
	 */
	public void WaitForElementVisibleWithPollingTime(WebElement element, int timeOutSeconds,
			int pollingEveryInMilliSec) {
		log.info("waiting for :" + element + " for :" + timeOutSeconds + " seconds");
		WebDriverWait wait = getWait(timeOutSeconds, pollingEveryInMilliSec);
		wait.until(ExpectedConditions.visibilityOf(element));
		log.info("element is visible now");

	}

	/**
	 * This method will make sure element is clickable
	 * 
	 * @param element
	 * @param timeOutSeconds
	 * @param pollingEveryInMilliSec
	 */
	public void WaitForElementClickable(WebElement element, int timeOutSeconds, int pollingEveryInMilliSec) {
		log.info("waiting for :" + element + " for :" + timeOutSeconds + " seconds");
		WebDriverWait wait = new WebDriverWait(driver, timeOutSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		log.info("element is clickable now");

	}

	/**
	 * This method will make sure invisiblity of element
	 * 
	 * @param element
	 * @param timeOutSeconds
	 * @return
	 */
	public boolean waitForElementNotPresent(WebElement element, long timeOutSeconds) {
		log.info("waiting for :" + element + " for :" + timeOutSeconds + " seconds");
		WebDriverWait wait = new WebDriverWait(driver, timeOutSeconds);
		boolean status = wait.until(ExpectedConditions.invisibilityOf(element));
		log.info("element is invisible now");
		return status;
	}

	/**
	 * This method will wait for frameToBeAvailableAndSwitchToIt
	 * 
	 * @param element
	 * @param timeOutSeconds
	 */
	public void waitframeToBeAvailableAndSwitchToIt(WebElement element, long timeOutSeconds) {
		log.info("waiting for :" + element + " for :" + timeOutSeconds + " seconds");
		WebDriverWait wait = new WebDriverWait(driver, timeOutSeconds);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
		log.info("frame is avialble and switched");
	}

	/**
	 * This method will give is fluentWait object
	 * 
	 * @param timeOutSeconds
	 * @param pollingEveryInMilliSec
	 * @return
	 */
	private Wait<WebDriver> getfluentWait(int timeOutSeconds, int pollingEveryInMilliSec) {
		Wait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(timeOutSeconds))
				.pollingEvery(Duration.ofMillis(pollingEveryInMilliSec)).ignoring(NoSuchElementException.class);
		return fWait;
	}

	/**
	 * 
	 * @param element
	 * @param timeOutSeconds
	 * @param pollingEveryInMilliSec
	 */
	public WebElement waitForElement(WebElement element, int timeOutSeconds, int pollingEveryInMilliSec) {
		Wait<WebDriver> fwait = getfluentWait(timeOutSeconds, pollingEveryInMilliSec);
		fwait.until(ExpectedConditions.visibilityOf(element));
		return element;
	}

	/**
	 * This method wait for page to be loaded
	 * 
	 * @param timeout
	 * @param unit
	 */
	public void pageLoadTime(long timeout, TimeUnit unit) {
		log.info("waiting for oage to load for :" + unit);
		driver.manage().timeouts().pageLoadTimeout(timeout, unit);
		log.info("page is loaded");
	}
}
