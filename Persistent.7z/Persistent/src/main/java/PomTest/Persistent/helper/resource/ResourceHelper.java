package PomTest.Persistent.helper.resource;

public class ResourceHelper {
	
	public static String getResourcePath(String path) {
		String basepath = System.getProperty("user.dir");
		return basepath + path;
	}
/*public static void main(String[] args) {
	String path =  ResourceHelper.getResourcePath("/Persistent/src/main/resources/configfile/log4j.properties");
	System.out.println(path);
}*/
}
