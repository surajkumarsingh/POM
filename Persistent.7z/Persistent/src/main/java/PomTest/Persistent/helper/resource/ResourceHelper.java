package PomTest.Persistent.helper.resource;

import org.apache.log4j.Logger;

import PomTest.Persistent.helper.logger.LoggerHelper;

/**
 * 
 * @author suraj_kumar
 *
 */
public class ResourceHelper {

	private static Logger log = LoggerHelper.getLogger(ResourceHelper.class);

	public static String getResourcePath(String path) {
		System.out.println(path);
		System.out.println(System.getProperty("user.dir"));
		//log.info("resource path: " + System.getProperty("user.dir") + "/" + path);
		String basePath = System.getProperty("user.dir");
		//System.out.println(basePath +"/"+path);
		return  path;
	}
	/*
	 * public static void main(String[] args) { String path =
	 * ResourceHelper.getResourcePath(
	 * "/Persistent/src/main/resources/configfile/log4j.properties");
	 * System.out.println(path); }
	 */
}
